from django.contrib import admin
from .models import *

admin.site.register(Fins)

# Register your models here.
