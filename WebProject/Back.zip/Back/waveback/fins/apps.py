from django.apps import AppConfig


class FinsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fins'
